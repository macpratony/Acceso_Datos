package Examen1;

public class Ireport {
	
	String nombre;
	String cantidad;
	
	
	public Ireport() {
		super();
	}


	public Ireport(String nombre, String cantidad) {
		super();
		this.nombre = nombre;
		this.cantidad = cantidad;
	}


	public String getNombre() {
		return nombre;
	}


	public void setNombre(String nombre) {
		this.nombre = nombre;
	}


	public String getCantidad() {
		return cantidad;
	}


	public void setCantidad(String cantidad) {
		this.cantidad = cantidad;
	}
	
	
	

}
